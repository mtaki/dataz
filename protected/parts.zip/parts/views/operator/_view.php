<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('telephone')); ?>:</b>
	<?php echo CHtml::encode($data->telephone); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fax')); ?>:</b>
	<?php echo CHtml::encode($data->fax); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('email')); ?>:</b>
	<?php echo CHtml::encode($data->email); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('town')); ?>:</b>
	<?php echo CHtml::encode($data->town); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('street')); ?>:</b>
	<?php echo CHtml::encode($data->street); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('plot_no')); ?>:</b>
	<?php echo CHtml::encode($data->plot_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('share_capital')); ?>:</b>
	<?php echo CHtml::encode($data->share_capital); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('contact_person')); ?>:</b>
	<?php echo CHtml::encode($data->contact_person); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('location')); ?>:</b>
	<?php echo CHtml::encode($data->location); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('address')); ?>:</b>
	<?php echo CHtml::encode($data->address); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('mobile')); ?>:</b>
	<?php echo CHtml::encode($data->mobile); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('type_name_business')); ?>:</b>
	<?php echo CHtml::encode($data->type_name_business); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('business_registration_number')); ?>:</b>
	<?php echo CHtml::encode($data->business_registration_number); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('registration_place')); ?>:</b>
	<?php echo CHtml::encode($data->registration_place); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('registration_date')); ?>:</b>
	<?php echo CHtml::encode($data->registration_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tin')); ?>:</b>
	<?php echo CHtml::encode($data->tin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('certificate_incorporation')); ?>:</b>
	<?php echo CHtml::encode($data->certificate_incorporation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('certificate_place')); ?>:</b>
	<?php echo CHtml::encode($data->certificate_place); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('certificate_date')); ?>:</b>
	<?php echo CHtml::encode($data->certificate_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('customer_code')); ?>:</b>
	<?php echo CHtml::encode($data->customer_code); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('country')); ?>:</b>
	<?php echo CHtml::encode($data->country); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('operator_type_id')); ?>:</b>
	<?php echo CHtml::encode($data->operator_type_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('occupation')); ?>:</b>
	<?php echo CHtml::encode($data->occupation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('contact_person_2')); ?>:</b>
	<?php echo CHtml::encode($data->contact_person_2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('postal_code')); ?>:</b>
	<?php echo CHtml::encode($data->postal_code); ?>
	<br />

	*/ ?>

</div>