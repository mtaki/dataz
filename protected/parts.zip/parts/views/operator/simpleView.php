<table  border="0" cellspacing="3" cellpadding="0" class='detail-view'>
	<tr style="background-color:#D7DEEE"><td colspan='4'>Contact Details</td></tr>
	<tr class='even'>
    <td><B>CONTACT PERSON</B></td><td><?php echo $model->contact_person; ?></td><td><B>CONTACT PERSON 2</B></td><td><?php echo $model->contact_person_2; ?></td>
  </tr>
  
  <tr class='even'>
    
    <td><B>EMAIL</B></td><td><?php echo $model->email; ?></td><td><B>MOBILE</B></td><td><?php echo $model->mobile; ?></td>
  </tr>
 </table>




