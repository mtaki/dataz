<?php
$file=$_REQUEST['file'];
include dirname(__FILE__).'/../../../docs/'.$file;
?>