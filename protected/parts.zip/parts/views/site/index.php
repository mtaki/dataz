<table height='420px'  width='840px' border="0"  cellpadding="0" cellspacing="0">
<tr><td height='30px'>&nbsp;</td><td width='102'></td></tr>
<tr>
	<td  style="background-image:url(images/front.png); background-repeat:no-repeat;width:600px;"></td>  
	<td>
	<table width='152px'>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('licenceApplication/new'); ?>'" >Licence Application</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('numberingApplication/new'); ?>'" >Numbering Application</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('statisticsTelecomMain/create'); ?>'" >Statistics</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('complaint/create'); ?>'" >Complaint</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('operator/admin'); ?>'" >Operators</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('invoice/admin'); ?>'" >Invoices</td></tr>
	<tr><td width='102px' height='50' class="shortcut" valign='middle' align="center" onclick="document.location.href='<?php echo Yii::app()->createUrl('user/admin'); ?>'" >Users</td></tr>
	</table>
	</td>
</tr>
</table>
