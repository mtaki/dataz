

<!-- h2>Error <?php echo $code; ?></h2-->

<div class="error">
<P />
<?php echo CHtml::encode($message); ?>

</div>