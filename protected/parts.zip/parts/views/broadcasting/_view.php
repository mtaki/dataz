<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_1')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_2')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_3')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_3); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_4')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_4); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('number_channel')); ?>:</b>
	<?php echo CHtml::encode($data->number_channel); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_unit')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_unit); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('operator_id')); ?>:</b>
	<?php echo CHtml::encode($data->operator_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('status')); ?>:</b>
	<?php echo CHtml::encode($data->status); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_type_id')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_type_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_sub_type_id')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_sub_type_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_trans_id')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_trans_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('band')); ?>:</b>
	<?php echo CHtml::encode($data->band); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('band_unit')); ?>:</b>
	<?php echo CHtml::encode($data->band_unit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('separation')); ?>:</b>
	<?php echo CHtml::encode($data->separation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('separation_unit')); ?>:</b>
	<?php echo CHtml::encode($data->separation_unit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('channel_band_width')); ?>:</b>
	<?php echo CHtml::encode($data->channel_band_width); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('channel_band_width_unit')); ?>:</b>
	<?php echo CHtml::encode($data->channel_band_width_unit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_band_width')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_band_width); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('frequency_band_width_unit')); ?>:</b>
	<?php echo CHtml::encode($data->frequency_band_width_unit); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('direction')); ?>:</b>
	<?php echo CHtml::encode($data->direction); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('zone')); ?>:</b>
	<?php echo CHtml::encode($data->zone); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('point_a')); ?>:</b>
	<?php echo CHtml::encode($data->point_a); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('point_b')); ?>:</b>
	<?php echo CHtml::encode($data->point_b); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('channel')); ?>:</b>
	<?php echo CHtml::encode($data->channel); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('region_id')); ?>:</b>
	<?php echo CHtml::encode($data->region_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('total_band_width')); ?>:</b>
	<?php echo CHtml::encode($data->total_band_width); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('band_width_unit')); ?>:</b>
	<?php echo CHtml::encode($data->band_width_unit); ?>
	<br />

	*/ ?>

</div>